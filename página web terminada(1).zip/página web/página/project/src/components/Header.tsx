import { Phone, MessageCircle, Menu, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { LOGO_URL, PHONE_DISPLAY, PHONE_TEL, WA_DEFAULT } from '@/constants';
import { trackConversion } from '@/analytics';

const NAV_LINKS = [
  { href: '#precios', label: 'Precios' },
  { href: '#proceso', label: 'Proceso' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contacto', label: 'Contacto' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 w-full z-50 transition-all duration-300 backdrop-blur-xl ${
        scrolled
          ? 'bg-surface-container-lowest/90 shadow-[0_1px_12px_rgba(0,0,0,0.5)]'
          : 'bg-surface-container-lowest/70'
      }`}
      role="banner"
    >
      <div className="h-20 max-w-container mx-auto px-6 flex items-center justify-between gap-4">
        {/* Logo */}
        <a href="#main" className="flex items-center gap-2.5 shrink-0">
          <div className="w-11 h-11 rounded-full bg-white p-1 shadow-glow flex items-center justify-center shrink-0 border border-white/20">
            <img src={LOGO_URL} alt="Logo LiproMaster" className="w-full h-full object-contain rounded-full" width={44} height={44} loading="eager" decoding="async" fetchPriority="high" />
          </div>
          <div>
            <span className="font-headline text-lg text-text-primary tracking-tight font-extrabold block">
              Lipro<span className="text-primary">Master</span>
            </span>
            <span className="text-[9px] text-primary font-code tracking-wider">Cuautitlán · Atizapán · Nicolás Romero</span>
          </div>
        </a>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-7" aria-label="Menú principal">
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-text-secondary hover:text-text-primary transition-colors font-medium min-h-[48px] flex items-center"
            >
              {l.label}
            </a>
          ))}
        </nav>

        {/* Desktop actions */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href={PHONE_TEL}
            className="inline-flex items-center gap-2 px-4 py-2 min-h-[48px] rounded-full bg-surface-container text-secondary text-sm hover:bg-surface-container-high transition-colors"
            aria-label={`Llamar al teléfono ${PHONE_DISPLAY}`}
          >
            <Phone size={16} />
            <span>{PHONE_DISPLAY}</span>
          </a>
          <a
            href={WA_DEFAULT}
            onClick={(event) => trackConversion(event, WA_DEFAULT)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2 min-h-[48px] rounded-full bg-primary-container text-white text-sm font-bold shadow-glow hover:shadow-glow-lg transition-all hover:scale-105"
            aria-label="Contactar por WhatsApp"
          >
            <MessageCircle size={16} />
            <span>WhatsApp</span>
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          className="lg:hidden inline-flex items-center justify-center w-12 h-12 rounded-lg bg-surface-container text-text-primary"
          onClick={() => setOpen((v) => !v)}
          aria-label="Abrir menú"
          aria-expanded={open}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <nav
          className="lg:hidden bg-surface-container-lowest/95 backdrop-blur-xl border-t border-white/5 px-6 py-5 flex flex-col gap-1"
          aria-label="Menú móvil"
        >
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="py-3.5 min-h-[48px] flex items-center text-text-secondary hover:text-text-primary transition-colors font-medium"
            >
              {l.label}
            </a>
          ))}
          <div className="flex flex-col gap-3 pt-4 mt-2 border-t border-white/5">
            <a
              href={PHONE_TEL}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[48px] rounded-full bg-surface-container text-secondary text-sm"
            >
              <Phone size={16} />
              <span>{PHONE_DISPLAY}</span>
            </a>
            <a
              href={WA_DEFAULT}
              onClick={(event) => {
                setOpen(false);
                trackConversion(event, WA_DEFAULT);
              }}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-[48px] rounded-full bg-primary-container text-white text-sm font-bold shadow-glow"
            >
              <MessageCircle size={16} />
              <span>Cotizar por WhatsApp</span>
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
