import { Star, Quote } from 'lucide-react';

const TESTIMONIALS = [
  {
    name: 'María González',
    location: 'Cuautitlán Izcalli',
    rating: 5,
    text: 'Quedé impresionada con el antes y después. El tinaco estaba muy sucio y quedó como nuevo. El reporte con fotos me dio mucha tranquilidad.',
  },
  {
    name: 'Carlos Ramírez',
    location: 'Naucalpan',
    rating: 5,
    text: 'Puntuales, profesionales y el precio fue justo. Se notó la diferencia en la limpieza desde el primer día. Recomendadísimo.',
  },
  {
    name: 'Laura Méndez',
    location: 'Atizapán',
    rating: 5,
    text: 'Tenía problemas de mal olor en el agua. Después del servicio desapareció por completo. Muy buena atención por WhatsApp.',
  },
];

export default function Testimonials() {
  return (
    <section className="w-full py-20 relative">
      <div className="max-w-container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
          <span className="text-xs text-primary uppercase tracking-widest font-code">[ 06 ] — TESTIMONIOS</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary">Familias que ya confían en LiproMaster</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.name}
              className="bg-surface-card border border-white/5 rounded-2xl p-6 relative hover:border-white/10 transition-colors"
            >
              <Quote className="text-primary/30 absolute top-5 right-5" size={36} aria-hidden="true" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} size={16} className="text-primary fill-primary" />
                ))}
              </div>
              <p className="text-sm text-text-secondary mb-5 relative z-10">"{t.text}"</p>
              <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-container to-tertiary flex items-center justify-center text-on-primary-container font-bold text-sm">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-bold text-text-primary">{t.name}</div>
                  <div className="text-xs text-text-muted">{t.location}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
