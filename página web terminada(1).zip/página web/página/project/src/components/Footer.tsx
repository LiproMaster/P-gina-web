import { Phone, MessageCircle, MapPin, Clock, Droplets, Instagram, Facebook } from 'lucide-react';
import { LOGO_URL, WA_DEFAULT, PHONE_DISPLAY, PHONE_TEL } from '@/constants';

export default function Footer() {
  return (
    <footer className="w-full bg-surface-container-lowest border-t border-white/5 pt-14 pb-8" role="contentinfo">
      <div className="max-w-container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-11 h-11 rounded-full bg-white p-1 shadow-glow flex items-center justify-center">
                <img src={LOGO_URL} alt="Logo oficial LiproMaster" className="w-full h-full object-contain rounded-full" width={44} height={44} loading="lazy" decoding="async" />
              </div>
              <span className="font-headline text-lg text-text-primary font-extrabold">
                Lipro<span className="text-primary">Master</span>
              </span>
            </div>
            <p className="text-sm text-text-secondary max-w-sm">
              Desinfección profunda y profesional de tinacos y cisternas en el Estado de México.
              Limpieza profesional para mantener 100% agua limpia en tu hogar.
            </p>
            <div className="flex items-center gap-2 text-primary">
              <Droplets size={18} />
              <span className="text-sm font-semibold">100% agua limpia</span>
            </div>
            <div className="pt-3">
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider mb-3">Síguenos</h3>
              <div className="flex items-center gap-4">
                <a
                  href="https://www.instagram.com/lipromaster?exln=MWFsYmNjY2lldDd5Mw=="
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Instagram de LiproMaster"
                  className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#E1306C]/15 text-[#E1306C] hover:bg-[#E1306C]/25 transition-colors"
                >
                  <Instagram size={20} />
                </a>
                <a
                  href="https://www.facebook.com/share/19UY4wTRL5/"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook de LiproMaster"
                  className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#1877F2]/15 text-[#1877F2] hover:bg-[#1877F2]/25 transition-colors"
                >
                  <Facebook size={20} />
                </a>
                <a
                  href="https://www.tiktok.com/@lipromaster"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="TikTok de LiproMaster"
                  className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#25F4EE]/15 text-[#25F4EE] hover:bg-[#25F4EE]/25 transition-colors"
                >
                  <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
                    <path d="M16.7 3c.3 1.8 1.3 3.1 3.3 3.4v3.1c-1.2-.1-2.3-.5-3.3-1.1v6.9c0 3.5-2.5 5.7-5.7 5.7-3 0-5.4-2.2-5.4-5.2 0-3.3 2.9-5.5 6.5-4.8v3.2c-1.6-.5-3.2.2-3.2 1.7 0 1.1.9 1.9 2 1.9 1.3 0 2.5-.8 2.5-2.7V3h3.3Z" />
                  </svg>
                </a>
              </div>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">Contacto</h3>
            <a href={PHONE_TEL} className="flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-colors min-h-[48px] py-1">
              <Phone size={16} className="text-primary" />
              {PHONE_DISPLAY}
            </a>
            <a
              href={WA_DEFAULT}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-colors min-h-[48px] py-1"
            >
              <MessageCircle size={16} className="text-primary" />
              WhatsApp
            </a>
            <div className="flex items-center gap-2 text-sm text-text-secondary">
              <MapPin size={16} className="text-primary" />
              Estado de México
            </div>
            <div className="flex items-center gap-2 text-sm text-text-secondary">
              <Clock size={16} className="text-primary" />
              Lun – Sáb: 9:00 – 15:00
            </div>
          </div>

          {/* Links */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">Servicio</h3>
            <ul className="space-y-3 text-sm">
              <li><a href="#beneficios" className="text-text-secondary hover:text-text-primary transition-colors inline-block min-h-[48px] py-2.5">Beneficios</a></li>
              <li><a href="#proceso" className="text-text-secondary hover:text-text-primary transition-colors inline-block min-h-[48px] py-2.5">Proceso</a></li>
              <li><a href="#precios" className="text-text-secondary hover:text-text-primary transition-colors inline-block min-h-[48px] py-2.5">Precios</a></li>
              <li><a href="#zonas" className="text-text-secondary hover:text-text-primary transition-colors inline-block min-h-[48px] py-2.5">Zonas de cobertura</a></li>
              <li><a href="#faq" className="text-text-secondary hover:text-text-primary transition-colors inline-block min-h-[48px] py-2.5">Preguntas frecuentes</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-text-secondary">
            © {new Date().getFullYear()} LiproMaster. Todos los derechos reservados.
          </p>
          <p className="text-xs text-text-secondary">
            Limpieza y desinfección profesional de tinacos y cisternas · Edomex
          </p>
        </div>
      </div>
    </footer>
  );
}
