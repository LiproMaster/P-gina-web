import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const FAQS = [
  {
    q: '¿Cada cuánto debo realizar el lavado?',
    a: 'Realiza el lavado cada 6 meses para mantener la buena calidad del agua almacenada. Si notas cambio de color u olor, agenda el servicio antes de ese periodo.',
  },
  {
    q: '¿Para qué puedo usar el agua después del servicio?',
    a: 'El agua queda lista para todas tus actividades diarias: bañarte, lavar trastes, lavarte los dientes y uso general en el hogar. Realiza el lavado cada 6 meses para mantener su buena calidad.',
  },
  {
    q: '¿Cuánto tarda el servicio?',
    a: 'En promedio entre 1.5 y 2.5 horas, dependiendo del tamaño del depósito y el nivel de suciedad. Al terminar puedes usar el agua para las actividades domésticas indicadas.'
  },
  {
    q: '¿Qué incluye el servicio?',
    a: 'Incluye extracción de residuos, lavado de superficies y desinfección del depósito para dejarlo listo para sus usos domésticos.',
  },
  {
    q: '¿Necesito estar presente durante el servicio?',
    a: 'Es recomendable que alguien esté presente para el acceso al tinaco. El proceso es controlado, no invasivo y no genera olores fuertes dentro de la casa.'
  },
  {
    q: '¿Aceptan pagos con tarjeta?',
    a: 'Aceptamos efectivo y transferencia. Para pago con tarjeta, consúltalo al momento de cotizar por WhatsApp y te informamos las opciones disponibles.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="w-full py-20 bg-surface-container-lowest relative" id="faq">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center space-y-3 mb-12">
          <span className="text-xs text-primary uppercase tracking-widest font-code">[ 07 ] — PREGUNTAS FRECUENTES</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary">Resolvemos tus dudas</h2>
        </div>

        <div className="space-y-3">
          {FAQS.map((f, i) => {
            const isOpen = open === i;
            return (
              <div
                key={f.q}
                className="bg-surface-container-low border border-white/5 rounded-xl overflow-hidden"
              >
                <button
                  className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left"
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                >
                  <span className="text-text-primary font-semibold text-sm sm:text-base">{f.q}</span>
                  <ChevronDown
                    size={20}
                    className={`text-primary shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                  />
                </button>
                <div
                  className={`grid transition-all duration-300 ${
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-sm text-text-secondary">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
