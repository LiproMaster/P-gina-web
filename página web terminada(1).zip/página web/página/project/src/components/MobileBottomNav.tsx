import { MessageCircle, Phone, Wallet, Waves } from 'lucide-react';
import { PHONE_TEL, WA_DEFAULT } from '@/constants';
import { trackConversion } from '@/analytics';

export default function MobileBottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden pb-[env(safe-area-inset-bottom)] bg-surface-container-lowest/95 backdrop-blur-xl border-t border-white/10" aria-label="Acciones rápidas">
      <div className="h-16 px-4 flex items-center justify-between gap-4">
        <a href="#main" className="flex flex-col items-center justify-center gap-1 min-h-[48px] min-w-[48px] py-1 text-primary text-[10px] font-code font-bold">
          <Waves size={20} /> Inicio
        </a>
        <a href="#precios" className="flex flex-col items-center justify-center gap-1 min-h-[48px] min-w-[48px] py-1 text-text-secondary text-[10px] font-code">
          <Wallet size={20} /> Precios
        </a>
        <a href={WA_DEFAULT} onClick={(event) => trackConversion(event, WA_DEFAULT)} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center justify-center gap-1 min-h-[48px] min-w-[48px] py-1 text-accent-whatsapp text-[10px] font-code">
          <MessageCircle size={20} /> WhatsApp
        </a>
        <a href={PHONE_TEL} className="flex flex-col items-center justify-center gap-1 min-h-[48px] min-w-[48px] py-1 text-text-secondary text-[10px] font-code">
          <Phone size={20} /> Llamar
        </a>
      </div>
    </nav>
  );
}
