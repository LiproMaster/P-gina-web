import { ShieldCheck, FileCheck2, Camera, Sparkles, HeartPulse, Clock3 } from 'lucide-react';

const BENEFITS = [
  {
    icon: ShieldCheck,
    title: 'Desinfección no invasiva',
    desc: 'Aplicamos solución clorada de grado alimenticio, segura para depósitos de agua y sin procesos invasivos.',
  },
  {
    icon: FileCheck2,
    title: 'Reporte con evidencia',
    desc: 'Cada servicio incluye documentación fotográfica del antes y después, para que veas el resultado con total transparencia.',
  },
  {
    icon: Camera,
    title: 'Reporte digital',
    desc: 'Recibes un reporte con evidencia fotográfica del estado del tinaco antes y después del servicio.',
  },
  {
    icon: Sparkles,
    title: 'Sin malos olores',
    desc: 'Retiramos sedimentos, biopelícula y residuos que generan mal sabor y olor en el agua.',
  },
  {
    icon: HeartPulse,
    title: 'Salud para tu familia',
    desc: 'El agua contaminada es fuente de enfermedades. Previene infecciones gastrointestinales y dérmicas.',
  },
  {
    icon: Clock3,
    title: 'Atención el mismo día',
    desc: 'Respuesta inmediata por WhatsApp. Agendamos en horas que se acomoden a tu rutina, lunes a sábado.',
  },
];

export default function Benefits() {
  return (
    <section className="w-full py-20 relative" id="beneficios">
      <div className="max-w-container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
          <span className="text-xs text-primary uppercase tracking-widest font-code">[ 02 ] — POR QUÉ ELEGIRNOS</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary">
            Agua Limpia es Salud para los Tuyos
          </h2>
          <p className="text-text-secondary">
            Desinfectamos con precisión profesional: solución clorada de grado alimenticio, cepillado técnico y extracción controlada.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {BENEFITS.map((b) => (
            <div
              key={b.title}
              className="group bg-surface-card hover:bg-surface-card-hover border border-white/5 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_12px_40px_rgba(0,0,0,0.3)]"
            >
              <div className="w-12 h-12 rounded-xl bg-primary-container/15 flex items-center justify-center mb-4 group-hover:bg-primary-container/25 transition-colors">
                <b.icon className="text-primary" size={24} />
              </div>
              <h3 className="text-lg font-bold text-text-primary mb-2">{b.title}</h3>
              <p className="text-sm text-text-secondary">{b.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
