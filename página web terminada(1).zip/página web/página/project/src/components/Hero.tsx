import { BadgeCheck, CheckCircle2, Clock, Filter, MessageCircle, ShieldCheck, Table2, Waves } from 'lucide-react';
import { WA_COTIZAR } from '@/constants';
import { trackConversion } from '@/analytics';

const BRAND_IMAGE_MOBILE_AVIF = '/brand-mobile.avif';

const BEFORE_IMAGE_MOBILE_AVIF = '/antes-mobile.avif';

const AFTER_IMAGE_MOBILE_AVIF = '/despues-mobile.avif';


const STATS = [
  { icon: ShieldCheck, value: '100%', label: 'Agua limpia' },
  { icon: Clock, value: '2 hrs', label: 'Tiempo promedio' },
  { icon: BadgeCheck, value: '6 meses', label: 'Lavado recomendado' },
];

export default function Hero() {
  return (
    <section className="relative w-full overflow-hidden pb-20 pt-10" id="hero">
      <div className="absolute -top-24 left-1/4 w-96 h-96 rounded-full bg-brand-emerald-glow blur-3xl pointer-events-none" aria-hidden="true" />
      <div className="absolute top-1/3 -right-20 w-[480px] h-[480px] rounded-full bg-brand-cyan-glow blur-3xl pointer-events-none" aria-hidden="true" />

      <div className="max-w-container mx-auto px-6 relative z-10">
        <div className="mb-10 rounded-2xl overflow-hidden border border-primary/30 shadow-xl shadow-primary/10 max-w-3xl mx-auto">
          <picture>
            <source media="(max-width: 768px)" srcSet={BRAND_IMAGE_MOBILE_AVIF} type="image/avif" width={480} height={480} />
            
            <source media="(min-width: 769px)" srcSet={BRAND_IMAGE_DESKTOP_AVIF} type="image/avif" width={768} height={420} />
            
            <img
              
              alt="LiproMaster: limpieza profunda y profesional de tinacos y cisternas"
              className="w-full max-h-[420px] object-cover"
              width={768}
              height={420}
              fetchPriority="high"
              loading="eager"
              decoding="async"
            />
          </picture>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 flex flex-col space-y-6">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded bg-surface-container text-primary font-code text-xs uppercase tracking-wider">
                [ 01 ] — SERVICIO CERTIFICADO EDOMEX
              </span>
              <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-surface-container-high text-secondary text-xs">
                <span className="inline-block w-2 h-2 rounded-full bg-primary animate-pulse" aria-hidden="true" />
                Lun – Sáb: 9:00 am – 3:00 pm • Atención Inmediata
              </div>
            </div>

            <div className="space-y-3">
              <span className="text-sm text-primary font-extrabold block tracking-wide">LIPROMASTER · SERVICIO LOCAL</span>
              <h1 className="text-4xl sm:text-5xl font-extrabold text-text-primary tracking-tight leading-[1.1]">
                Limpieza Profunda y Profesional de{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-tertiary to-secondary">Tinacos y Cisternas</span>
              </h1>
            </div>

            <p className="text-base sm:text-lg text-text-secondary max-w-xl">
              Después del servicio disfruta de 100% agua limpia en tu hogar. Realiza el lavado cada 6 meses para mantener su buena calidad y proteger a tu familia.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <a
                href={WA_COTIZAR}
                onClick={(event) => trackConversion(event, WA_COTIZAR)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-primary-container hover:bg-primary text-white text-base font-bold shadow-glow transition-all hover:scale-105"
              >
                <MessageCircle size={20} />
                Cotizar por WhatsApp
              </a>
              <a href="#precios" className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-surface-container-high hover:bg-surface-bright text-text-primary text-base transition-all">
                <Table2 size={20} className="text-secondary" />
                Ver Matriz de Precios
              </a>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-6 max-w-md">
              {STATS.map((stat) => (
                <div key={stat.label} className="text-center sm:text-left">
                  <stat.icon className="text-primary mx-auto sm:mx-0 mb-1" size={22} />
                  <div className="text-xl font-extrabold text-text-primary font-code">{stat.value}</div>
                  <div className="text-xs text-text-muted">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-6 relative">
            <div className="rounded-2xl border border-emerald-500/30 bg-surface-container-low/90 p-4 shadow-lg shadow-emerald-500/10 backdrop-blur-xl">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-xs font-code uppercase tracking-[0.2em] text-text-muted">Diagnóstico visual</span>
                  <h2 className="text-lg font-bold text-text-primary">Antes / Después</h2>
                </div>
                <div className="flex items-center gap-2 text-xs text-primary"><CheckCircle2 size={16} /> Evidencia del servicio</div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="relative overflow-hidden rounded-xl border border-red-400/30 min-h-[250px]">
                  <picture>
                    <source media="(max-width: 768px)" srcSet={BEFORE_IMAGE_MOBILE_AVIF} type="image/avif" />
                    
                    <source media="(min-width: 769px)" srcSet={BEFORE_IMAGE_DESKTOP_AVIF} type="image/avif" />
                    
                    <img
              
                      alt="Cisterna sucia antes del servicio"
                      className="absolute inset-0 w-full h-full object-cover brightness-75"
                      width={400}
                      height={179}
                      loading="lazy"
                      decoding="async"
                    />
                  </picture>
                  <div className="absolute inset-0 bg-gradient-to-t from-red-950/80 via-transparent to-transparent" />
                  <span className="absolute top-3 left-3 rounded-full bg-red-500/90 px-3 py-1 text-xs font-bold text-white">ANTES</span>
                  <span className="absolute bottom-3 left-3 text-xs font-medium text-red-100">Tinaco manchado y sucio</span>
                </div>
                <div className="relative overflow-hidden rounded-xl border border-emerald-400/40 min-h-[250px]">
                  <picture>
                    <source media="(max-width: 768px)" srcSet={AFTER_IMAGE_MOBILE_AVIF} type="image/avif" />
                    
                    <source media="(min-width: 769px)" srcSet={AFTER_IMAGE_DESKTOP_AVIF} type="image/avif" />
                    
                    <img

                      alt="Cisterna limpia con agua clara después del servicio"
                      className="absolute inset-0 w-full h-full object-cover brightness-110 saturate-125"
                      width={400}
                      height={894}
                      loading="lazy"
                      decoding="async"
                    />
                  </picture>
                  <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/70 via-transparent to-transparent" />
                  <span className="absolute top-3 left-3 rounded-full bg-primary-container px-3 py-1 text-xs font-bold text-on-primary-container">DESPUÉS</span>
                  <span className="absolute bottom-3 left-3 text-xs font-medium text-emerald-50">Tinaco limpio y desinfectado</span>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2 rounded-lg bg-surface-container/70 px-3 py-2 text-xs text-text-secondary"><Waves size={16} className="text-tertiary shrink-0" /> Desinfección clorada</div>
                <div className="flex items-center gap-2 rounded-lg bg-surface-container/70 px-3 py-2 text-xs text-text-secondary"><Filter size={16} className="text-secondary shrink-0" /> Extracción por bomba</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
