import { CheckCircle2, MapPin, MessageCircle, Route } from 'lucide-react';
import { WA_MANTENIMIENTO } from '@/constants';
import { trackConversion } from '@/analytics';

const MUNICIPALITIES = [
  {
    name: 'Cuautitlán Izcalli',
    tone: 'primary',
    neighborhoods: ['Centro Urbano', 'Cumbria', 'Arcos del Alba', 'Bosques del Lago', 'Jardines de la Hacienda', 'Ensueños', 'Atlanta', 'San Antonio', 'Tepalcapa', 'Santa María Guadalupe las Torres'],
  },
  {
    name: 'Atizapán de Zaragoza',
    tone: 'tertiary',
    neighborhoods: ['Zona Esmeralda', 'Las Arboledas', 'Valle Dorado', 'Mayorazgos del Bosque', 'Calacoaya', 'Las Alamedas', 'Fuentes de Satélite', 'El Campanario', 'Lomas de Atizapán', 'Club de Golf Hacienda'],
  },
  {
    name: 'Nicolás Romero',
    tone: 'secondary',
    neighborhoods: ['Ciudad Nicolás Romero', 'San Ildefonso', 'La Colmena', 'Progreso Industrial', 'Cahuacán', 'San José el Vidrio', 'Barrón', 'San Pedro', 'Loma del Río', 'San Juan de las Tablas'],
  },
];

export default function ServiceAreas() {
  return (
    <section className="w-full py-20 bg-surface-container-lowest relative" id="zonas">
      <div className="max-w-container mx-auto px-6">
        <div className="max-w-3xl mb-10">
          <span className="text-xs text-primary uppercase tracking-widest font-code">[ 05 ] — COBERTURA LOCAL</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary mt-3">Servicio directo en tres municipios</h2>
          <p className="text-text-secondary mt-3">Estas son nuestras zonas principales y algunas de las colonias más solicitadas. Si estás fuera de ellas, también podemos atenderte con una tarifa diferente según la distancia.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {MUNICIPALITIES.map((municipality) => (
            <article key={municipality.name} className="rounded-2xl bg-surface-card border border-white/5 p-5 hover:border-primary/30 transition-colors">
              <div className="flex items-center gap-3 mb-5">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${municipality.tone === 'primary' ? 'bg-primary/15 text-primary' : municipality.tone === 'tertiary' ? 'bg-tertiary/15 text-tertiary' : 'bg-secondary/15 text-secondary'}`}>
                  <MapPin size={22} />
                </div>
                <div>
                  <h3 className="font-bold text-text-primary">{municipality.name}</h3>
                  <span className="text-xs text-text-muted">Ruta prioritaria</span>
                </div>
              </div>
              <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
                {municipality.neighborhoods.map((neighborhood) => (
                  <li key={neighborhood} className="flex items-center gap-2 text-sm text-text-secondary">
                    <CheckCircle2 size={14} className="text-primary shrink-0" />
                    {neighborhood}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>

        <div className="mt-6 rounded-2xl border border-cyan-400/30 bg-cyan-400/10 p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Route className="text-cyan-300 shrink-0 mt-0.5" size={22} />
            <div>
              <h3 className="font-bold text-text-primary">¿Tu domicilio está en otro municipio?</h3>
              <p className="text-sm text-cyan-50/80 mt-1">Sí damos servicio fuera de estas tres zonas; el costo cambia por traslado y se confirma antes de agendar.</p>
            </div>
          </div>
          <a href={WA_MANTENIMIENTO} onClick={(event) => trackConversion(event, WA_MANTENIMIENTO)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-cyan-400/15 border border-cyan-300/40 px-4 py-2.5 min-h-[48px] text-sm font-bold text-cyan-100 hover:bg-cyan-400/25 transition-colors shrink-0">
            <MessageCircle size={17} />
            Consultar traslado
          </a>
        </div>
      </div>
    </section>
  );
}
