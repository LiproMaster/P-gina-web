import { useMemo, useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { PRICING_PACKAGES } from '@/constants';
import { trackConversion } from '@/analytics';

type PackageFilter = 'todos' | 'combos' | 'tinacos' | 'cisternas';

const FILTERS: { value: PackageFilter; label: string }[] = [
  { value: 'todos', label: 'Todos (6)' },
  { value: 'combos', label: 'Combos populares' },
  { value: 'tinacos', label: 'Tinacos' },
  { value: 'cisternas', label: 'Cisternas' },
];

export default function Pricing() {
  const [filter, setFilter] = useState<PackageFilter>('todos');
  const packages = useMemo(() => filter === 'todos' ? PRICING_PACKAGES : PRICING_PACKAGES.filter((pkg) => pkg.category === filter), [filter]);

  return (
    <section className="w-full py-20 relative" id="precios">
      <div className="max-w-container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
          <span className="text-xs text-primary uppercase tracking-widest font-code">[ 02 ] — MATRIZ TRANSPARENTE</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary">Paquetes y Precios Oficiales</h2>
          <p className="text-text-secondary">Precios fijos sin cobros sorpresa. Incluye nota digital en PDF y recomendación de lavado cada 6 meses.</p>
        </div>

        <div className="flex items-center gap-2 p-1 mb-6 rounded-xl bg-surface-container-high border border-white/5 overflow-x-auto custom-scroll">
          {FILTERS.map((item) => (
            <button
              key={item.value}
              type="button"
              onClick={() => setFilter(item.value)}
              className={`shrink-0 px-4 py-2 min-h-[48px] rounded-lg text-xs font-bold transition-all flex items-center ${filter === item.value ? 'bg-primary text-on-primary-container' : 'text-text-secondary hover:text-text-primary'}`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {packages.map((pkg) => {
            const featured = pkg.id === 'casa-estandar';
            return (
              <article key={pkg.id} className={`relative rounded-2xl p-7 border flex flex-col transition-all duration-300 hover:-translate-y-1 ${featured ? 'bg-gradient-to-b from-surface-container-high to-surface-card border-2 border-primary shadow-xl shadow-primary/10' : 'bg-surface-card border-white/5 hover:border-cyan-400/30'}`}>
                {pkg.badge && <span className="absolute -top-3 right-5 px-3 py-1 rounded-full bg-gradient-to-r from-primary to-tertiary text-on-primary-container font-code text-[10px] font-extrabold tracking-wider shadow">{pkg.badge}</span>}
                <div className="mb-3">
                  <span className="text-[11px] font-code uppercase tracking-wider text-tertiary font-bold">{featured ? 'Combo residencial integral' : pkg.category === 'tinacos' ? 'Básico residencial' : pkg.category === 'cisternas' ? 'Estructura especializada' : 'Multinivel residencial'}</span>
                  <h3 className="text-xl font-extrabold text-text-primary mt-1">{pkg.name}</h3>
                </div>
                <p className="text-sm text-text-secondary leading-7 flex-1 mb-7">{pkg.description}</p>
                <div className="mb-5 pt-4 border-t border-white/10">
                  <span className="text-4xl font-extrabold font-code text-primary">${pkg.price.toLocaleString('es-MX')}</span>
                  <span className="ml-2 text-sm text-text-muted">MXN</span>
                </div>
                <a href={pkg.waLink} onClick={(event) => trackConversion(event, pkg.waLink)} target="_blank" rel="noopener noreferrer" className={`inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[48px] rounded-xl font-bold text-sm transition-all ${featured ? 'bg-primary-container text-white shadow-glow hover:shadow-glow-lg' : 'bg-primary-container text-white hover:bg-primary'}`}>
                  <MessageCircle size={18} />
                  {featured ? 'Agendar Casa Estándar' : `Agendar ${pkg.name}`}
                </a>
              </article>
            );
          })}
        </div>

        <div className="mt-8 rounded-xl border border-white/10 bg-surface-container-low/70 p-5 text-sm text-text-secondary leading-6">
          * Todos los servicios incluyen nota de servicio digital en formato PDF. En caso de requerir nota impresa en físico, favor de avisar antes de realizar el servicio.
        </div>
        <div className="mt-4 rounded-xl border border-primary/40 bg-primary/10 px-5 py-4 text-center text-sm text-primary">
          <span className="font-bold">Promoción “Vecinos Unidos”:</span> $1,350 MXN c/u al agendar dos casas el mismo día.
        </div>
      </div>
    </section>
  );
}
