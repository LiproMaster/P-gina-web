import { ClipboardCheck, Droplets, FileCheck, ShieldCheck } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface ProcessStep {
  icon: LucideIcon;
  n: string;
  title: string;
  desc: string;
}

const STEPS: ProcessStep[] = [
  {
    icon: ClipboardCheck,
    n: '01',
    title: 'Inspección y preparación',
    desc: 'Revisamos accesos, capacidad, válvulas y nivel de sedimentos antes de iniciar el servicio.',
  },
  {
    icon: Droplets,
    n: '02',
    title: 'Extracción por bomba sumergible',
    desc: 'Retiramos lodos y residuos de forma controlada, sin poner en riesgo la estructura del depósito.',
  },
  {
    icon: ShieldCheck,
    n: '03',
    title: 'Cepillado y desinfección',
    desc: 'Realizamos cepillado mecánico/manual y aplicamos desinfección clorada de grado alimenticio.',
  },
  {
    icon: FileCheck,
    n: '04',
    title: 'Enjuague y entrega',
    desc: 'Completamos el enjuague, verificamos el resultado y enviamos nota digital PDF con el reporte del servicio.',
  },
];

export default function Process() {
  return (
    <section className="w-full py-20 bg-surface-container-lowest relative" id="proceso">
      <div className="max-w-container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
          <span className="text-xs text-primary uppercase tracking-widest font-code">[ 03 ] — PROTOCOLO TÉCNICO</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary">Un proceso limpio, seguro y trazable</h2>
          <p className="text-text-secondary">Cuatro pasos profesionales para devolverle seguridad a tu reserva de agua.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {STEPS.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.n} className="relative">
                <div className="bg-surface-container-low border border-white/5 rounded-2xl p-6 h-full hover:border-primary/30 transition-colors">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-11 h-11 rounded-xl bg-surface-container-high flex items-center justify-center">
                      <Icon className="text-primary" size={22} />
                    </div>
                    <span className="font-code text-2xl font-bold text-surface-bright">{step.n}</span>
                  </div>
                  <h3 className="text-base font-bold text-text-primary mb-2">{step.title}</h3>
                  <p className="text-sm text-text-secondary">{step.desc}</p>
                </div>
                {index < STEPS.length - 1 && <div className="hidden lg:block absolute top-1/2 -right-2 w-4 h-px bg-gradient-to-r from-primary/40 to-transparent" aria-hidden="true" />}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
