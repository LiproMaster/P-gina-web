import { MessageCircle } from 'lucide-react';
import { WA_DEFAULT } from '@/constants';
import { trackConversion } from '@/analytics';

export default function FloatingWhatsApp() {
  return (
    <a
      href={WA_DEFAULT}
      onClick={(event) => trackConversion(event, WA_DEFAULT)}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 left-6 z-50 inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary-container text-white shadow-glow-lg hover:scale-110 transition-transform"
      aria-label="Contactar por WhatsApp"
    >
      <MessageCircle size={28} />
      <span className="absolute inline-flex w-14 h-14 rounded-full bg-primary-container opacity-60 animate-ping" aria-hidden="true" />
    </a>
  );
}
