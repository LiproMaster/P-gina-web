import { MessageCircle, Phone, Droplets } from 'lucide-react';
import { WA_COTIZAR, PHONE_DISPLAY, PHONE_TEL } from '@/constants';
import { trackConversion } from '@/analytics';

export default function CTA() {
  return (
    <section className="w-full py-20 relative overflow-hidden" id="contacto">
      <div className="absolute inset-0" aria-hidden="true">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-brand-emerald-glow blur-3xl" />
      </div>
      <div className="max-w-container mx-auto px-6 relative z-10">
        <div className="bg-gradient-to-br from-surface-container to-surface-container-low border border-primary/20 rounded-3xl p-8 sm:p-12 text-center space-y-6 shadow-2xl">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-primary-container/20 flex items-center justify-center">
            <Droplets className="text-primary" size={32} />
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary max-w-2xl mx-auto leading-tight">
            ¿Listo para una cisterna limpia y segura?
          </h2>
          <p className="text-text-secondary max-w-xl mx-auto">
            Cotiza en minutos por WhatsApp. Desinfección profesional, atención inmediata y lavado recomendado cada 6 meses.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <a
              href={WA_COTIZAR}
              onClick={(event) => trackConversion(event, WA_COTIZAR)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-primary-container hover:bg-primary text-white text-base font-bold shadow-glow transition-all hover:scale-105"
            >
              <MessageCircle size={20} />
              <span>Cotizar por WhatsApp</span>
            </a>
            <a
              href={PHONE_TEL}
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-surface-container-high hover:bg-surface-bright text-text-primary text-base font-semibold transition-all"
            >
              <Phone size={20} className="text-secondary" />
              <span>{PHONE_DISPLAY}</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
