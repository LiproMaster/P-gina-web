export function trackConversion(event: { preventDefault: () => void }, url: string): void {
  if (typeof window.gtag_report_conversion === 'function') {
    event.preventDefault();
    window.gtag_report_conversion(url);
  }
}
