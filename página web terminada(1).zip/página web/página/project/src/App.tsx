import React, { lazy, Suspense } from 'react';

// Se cargan de inmediato para ver la primera pantalla rápido
import Header from '@/components/Header';
import Hero from '@/components/Hero';

// Carga diferida para componentes abajo de la pantalla inicial
const Pricing = lazy(() => import('@/components/Pricing'));
const Benefits = lazy(() => import('@/components/Benefits'));
const Process = lazy(() => import('@/components/Process'));
const ServiceAreas = lazy(() => import('@/components/ServiceAreas'));
const Testimonials = lazy(() => import('@/components/Testimonials'));
const FAQ = lazy(() => import('@/components/FAQ'));
const CTA = lazy(() => import('@/components/CTA'));
const Footer = lazy(() => import('@/components/Footer'));
const FloatingWhatsApp = lazy(() => import('@/components/FloatingWhatsApp'));
const MobileBottomNav = lazy(() => import('@/components/MobileBottomNav'));

export default function App() {
  return (
    <div className="min-h-screen bg-surface-50">
      <Header />
      <main id="main" className="w-full pt-20">
        <Hero />
        <Suspense fallback={<div className="min-h-[200px]" />}>
          <Pricing />
          <Benefits />
          <Process />
          <ServiceAreas />
          <Testimonials />
          <FAQ />
          <CTA />
        </Suspense>
      </main>
      <Suspense fallback={null}>
        <Footer />
        <FloatingWhatsApp />
        <MobileBottomNav />
      </Suspense>
    </div>
  );
}
