export const PHONE_DISPLAY = '56 3183 8370';
export const PHONE_TEL = 'tel:+525631838370';
export const LOGO_URL = 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0GNc_KTqycQV8O_JQaZSPQC3YnQrGX89NSIp17011ZW__qzinVpunLewQVj1gLV5V52E2xWcI2MyEslcrhT4MpsrM2mwZu13lc2Ixrdci3B0x8DDT4Ju1QlIgCHo5lieXuKAziKC3mp93bUYTSkXxnUsoe9clDxgTXk8VKUOPAHWTwz6-om3DIwJLGlcZxMElD8JfNBmSZG1ToM4J3LVLbIRbwqL87UBYjKJiIEcERN6vSYMI7tQirS5BvYfWQpIKzw';
export const WHATSAPP_BASE = 'https://wa.me/525631838370';

export function whatsappLink(message: string): string {
  return `${WHATSAPP_BASE}?text=${encodeURIComponent(message)}`;
}

export const WA_DEFAULT = whatsappLink('Hola LiproMaster, me interesa cotizar la desinfección de mi tinaco o cisterna');
export const WA_COTIZAR = whatsappLink('Hola LiproMaster, me interesa agendar una desinfección profunda de mi tinaco o cisterna');
export const WA_MANTENIMIENTO = whatsappLink('Hola LiproMaster, quiero verificar disponibilidad en mi zona');

export interface PricingPackage {
  id: string;
  name: string;
  description: string;
  price: number;
  badge?: string;
  waLink: string;
  category: 'combos' | 'tinacos' | 'cisternas';
}

export const PRICING_PACKAGES: PricingPackage[] = [
  {
    id: 'tinaco-individual',
    name: 'Tinaco Individual',
    description: 'Desinfección profunda no invasiva para tinacos de superficie de hasta 1,100 litros. Incluye extracción por bomba sumergible, cepillado mecánico y solución clorada de grado alimenticio.',
    price: 700,
    category: 'tinacos',
    waLink: whatsappLink('Hola LiproMaster, me interesa agendar el servicio de Tinaco Individual'),
  },
  {
    id: 'cisterna-concreto',
    name: 'Solo Cisterna Subterránea de Concreto',
    description: 'Extracción profunda de lodos, cepillado de muros y desinfección clorada de grado alimenticio para cisterna subterránea de hasta 10,000 litros.',
    price: 1200,
    category: 'cisternas',
    waLink: whatsappLink('Hola LiproMaster, me interesa agendar el servicio de Solo Cisterna Subterranea'),
  },
  {
    id: 'deposito-plastico',
    name: 'Tinaco o Cisterna de Plástico',
    description: 'Tratamiento técnico no abrasivo para depósitos plásticos, de superficie o enterrados, de hasta 10,000 litros. Incluye extracción por bomba sumergible.',
    price: 1200,
    category: 'cisternas',
    waLink: whatsappLink('Hola LiproMaster, me interesa agendar el servicio de Tinaco o Cisterna de Plastico'),
  },
  {
    id: 'casa-estandar',
    name: 'Paquete Casa Estándar',
    badge: 'MÁS POPULAR',
    description: 'Servicio residencial integral: desinfección de 1 cisterna subterránea de hasta 10,000 litros más 1 tinaco de superficie, con nota digital y reporte fotográfico.',
    price: 1600,
    category: 'combos',
    waLink: whatsappLink('Hola LiproMaster, me interesa agendar el Paquete Casa Estandar'),
  },
  {
    id: 'casa-grande',
    name: 'Paquete Casa Grande',
    description: 'Cobertura completa para residencias amplias: desinfección de 1 cisterna subterránea de hasta 10,000 litros más 2 tinacos.',
    price: 2000,
    category: 'combos',
    waLink: whatsappLink('Hola LiproMaster, me interesa agendar el Paquete Casa Grande'),
  },
  {
    id: 'tanque-elevado',
    name: 'Tanque Elevado de Concreto',
    description: 'Trabajo técnico especializado en altura y desinfección de estructuras elevadas de concreto de hasta 10,000 litros, con protocolo seguro de acceso.',
    price: 2350,
    category: 'cisternas',
    waLink: whatsappLink('Hola LiproMaster, me interesa agendar el servicio de Tanque Elevado'),
  },
];
