import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          // Si el archivo viene de la carpeta node_modules (dependencias externas)
          if (id.includes('node_modules')) {
            // Separa React en su propio archivo independiente
            if (id.includes('react') || id.includes('react-dom')) {
              return 'vendor-react';
            }
            // Separa cualquier otra librería externa pesada en otro archivo
            return 'vendor-libs';
          }
        },
      },
    },
    // Ajusta el límite de advertencia de tamaño para mantener el control
    chunkSizeWarningLimit: 600,
  },
});
