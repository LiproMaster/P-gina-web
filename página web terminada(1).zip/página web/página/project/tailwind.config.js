/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'surface-canvas': '#070C1A',
        'surface-container': '#0B132B',
        'surface-container-low': '#0B132B',
        'surface-container-lowest': '#050811',
        'surface-container-high': '#101833',
        'surface-container-highest': '#16203F',
        'surface-bright': '#1F2A4A',
        'surface-card': 'rgba(11, 19, 43, 0.9)',
        'surface-card-hover': 'rgba(16, 32, 63, 0.95)',
        primary: {
          DEFAULT: '#10B981',
          container: '#10b981',
          on: '#003824',
          'on-container': '#00422b',
        },
        secondary: '#89ceff',
        tertiary: '#06B6D4',
        'accent-whatsapp': '#25D366',
        'text-primary': '#FFFFFF',
        'text-secondary': '#CBD5E1',
        'text-muted': '#CBD5E1',
        error: '#ffb4ab',
        warning: '#fbbf24',
        'brand-emerald-glow': 'rgba(16, 185, 129, 0.18)',
        'brand-cyan-glow': 'rgba(6, 182, 212, 0.18)',
      },
      fontFamily: {
        body: ['Plus Jakarta Sans', 'sans-serif'],
        headline: ['Plus Jakarta Sans', 'sans-serif'],
        code: ['Space Grotesk', 'monospace'],
      },
      maxWidth: {
        container: '1240px',
      },
      boxShadow: {
        glow: '0 8px 28px rgba(16,185,129,0.35)',
        'glow-lg': '0 6px 24px rgba(16,185,129,0.5)',
      },
    },
  },
  plugins: [],
};
